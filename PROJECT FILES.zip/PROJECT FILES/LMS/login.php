<?php
include 'file/connection.php'; 
session_start();

if (isset($_POST["submited"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $stmt = $conn->prepare("SELECT * FROM employees WHERE name=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($result->num_rows > 0) {
        if ($password == $row["password"]) {
            $_SESSION["login"] = true;
            $_SESSION["id"] = $row["id"];
            $_SESSION["name"] = $row["name"];
            
            // Insert login action into logs table
            $emp_name = $row["name"];
            $applicant_id = '';
            $action_type = 'login';
            $timestamp = date('Y-m-d H:i:s');
            $log_stmt = $conn->prepare("INSERT INTO logs (emp_name, applicant_id, type_of_action, date_time) VALUES (?, ?, ?, ?)");
            $log_stmt->bind_param("ssss", $emp_name, $applicant_id, $action_type, $timestamp);
            $log_stmt->execute();
            
            header("Location: loggedin.php");
        } else {
            echo "<script>alert('Wrong Password');</script>";
        }
    } else {
        echo "<script>alert('User not registered, please register before login');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html>
<head>
<?php $title = "Bank System | User Login"; ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/style5.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/swiper-bundle.min.css">
<link rel="stylesheet" href="css/styletry.css">
<style>
body {
    overflow-x: hidden;
    font-family: Arial, sans-serif;
    background: url('https://www.digicontacts.net/wp-content/uploads/2024/02/banque-societe-generale-afrique.jpg') no-repeat center center fixed;
    background-size: cover;
}

.container {
    max-width: 400px;
    width: 100%;
    background: linear-gradient(135deg, #ff0000, #000000);
    color: #fff;
    margin: 50px 0;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    position: absolute;
    left: 20px; /* Adjust this value as needed to position the container */
    top: 100px; /* Adjust this value to move the container down */
}

.container .title {
    font-size: 24px;
    font-weight: 700;
    margin-bottom: 25px;
    color: #fff;
    text-transform: uppercase;
    text-align: center;
}

.container .form {
    width: 100%;
}

.container .form .input_field {
    margin-bottom: 15px;
}

.container .form .input_field label {
    width: 100%;
    margin-bottom: 5px;
    font-size: 14px;
    color: #fff;
}

.container .form .input_field .input {
    width: 100%;
    outline: none;
    border: 1px solid #ccc;
    font-size: 15px;
    padding: 10px;
    border-radius: 5px;
    transition: all 0.3s ease;
}

.container .form .input_field .input:focus {
    border-color: #ff0000;
}

.container .form .input_field .btn {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: none;
    background: #ff0000;
    color: white;
    cursor: pointer;
    border-radius: 5px;
    transition: background 0.3s ease;
}

.container .form .input_field .btn:hover {
    background: #cc0000;
}

a {
    display: block;
    margin-top: 10px;
    text-align: center;
    color: #ff0000;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
<div class="container">
    <form action="" method="POST">
        <div class="title">User Login</div>
        <div class="form">
            <div class="input_field">
                <label for="username">Username</label>
                <input type="text" class="input" name="username" required>
            </div>
            <div class="input_field">
                <label for="password">Password</label>
                <input type="password" class="input" name="password" required>
            </div>
            <div class="input_field">
                <input type="submit" value="Submit" class="btn" name="submited">
            </div>
        </div>
    </form>
    <a href="register.php">Don't have an account? Register here</a>
</div>
</body>
</html>
