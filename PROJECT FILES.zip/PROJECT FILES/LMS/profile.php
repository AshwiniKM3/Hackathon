<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Employee Profile</title>
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(to bottom right, #e040fb, #ff4081); /* Purple and pink gradient background */
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh; /* Ensure full viewport height */
}

.container {
    width: 90%;
    max-width: 600px; /* Adjusted max-width */
    background-color: #fff;
    padding: 30px; /* Increased padding for more space */
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    text-align: center;
}

.profile {
    margin-bottom: 20px;
}

.profile img {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    object-fit: cover;
    border: 5px solid #fff; /* White border */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease-in-out; /* Smooth hover effect */
}

.profile img:hover {
    transform: scale(1.1); /* Scale up on hover */
}

.profile h2 {
    margin: 10px 0 5px;
    color: #333;
    font-size: 2.2em; /* Larger font size */
}

.profile p {
    color: #666;
    font-size: 1.2em;
    margin-bottom: 0;
}

.profile .designation {
    font-style: italic;
    color: #888;
    margin-top: 5px;
}

.quote {
    font-style: italic;
    color: #555;
    margin-top: 20px;
    font-size: 1.2em;
}

.welcome-header {
    background-color: #43cea2; /* Light green background */
    color: #fff; /* White text */
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 20px;
    font-size: 1.5em;
}
</style>
</head>
<body>
<div class="container">
    <div class="welcome-header">
        Welcome back!
    </div>
    <div class="profile">
        <img src="https://i0.wp.com/www.steverrobbins.com/wp-content/uploads/ceo-midjourney-office.jpg?resize=1024%2C683&ssl=1" alt="CEO Office Profile Picture">
        <h2>Lilly Smith</h2>
        <p class="designation">Loan Manager</p>
        <p>MBA in Finance, Certified Loan Specialist</p>
        <div class="quote">
            "Helping dreams come true, one loan at a time."
        </div>
    </div>
    <!-- Other sections or details can be added here -->
</div>
</body>
</html>
