<?php 
require 'file/connection.php';
session_start();

// Function to log actions
function logAction($emp_name, $applicant_id, $action, $conn) {
    $timestamp = date('Y-m-d H:i:s');
    $log_stmt = $conn->prepare("INSERT INTO logs (emp_name, applicant_id, type_of_action, date_time) VALUES (?, ?, ?, ?)");
    $log_stmt->bind_param("ssss", $emp_name, $applicant_id, $action, $timestamp);
    $log_stmt->execute();
    $log_stmt->close();
}

if (isset($_SESSION['name'])) {
    $emp_name = $_SESSION['name'];
    $applicant_id = '';
    $action = 'logout';
    logAction($emp_name, $applicant_id, $action, $conn);
}

// Clear session data and destroy session
$_SESSION = [];
session_unset();
session_destroy();
header("Location: login.php");
exit();
?>