<?php 
require 'file/connection.php';
session_start();

// Function to log actions
function logAction($emp_name, $applicant_id, $action, $conn) {
    $timestamp = date('Y-m-d H:i:s');
    $log_stmt = $conn->prepare("INSERT INTO logs (emp_name, applicant_id, type_of_action, date_time) VALUES (?, ?, ?, ?)");
    $log_stmt->bind_param("ssss", $emp_name, $applicant_id, $action, $timestamp);
    $log_stmt->execute();
    $log_stmt->close();
}

// Function to handle application verification
if (isset($_POST['verify_application'])) {
    $applicant_id = $_POST['verify_application'];
    $current_time = date('Y-m-d H:i:s');
    $emp_name = $_SESSION['name'];

    // Insert into verified_applications table
    $sql_verify = "INSERT INTO verified_applications (applicant_ID, verified_at) VALUES ('$applicant_id', '$current_time')";
    if ($conn->query($sql_verify) === TRUE) {
        $message = "Application successfully verified.";
        logAction($emp_name, $applicant_id, "verify_application", $conn);
    } else {
        $message = "Error verifying application: " . $conn->error;
    }
}

try {
    // Query for pending applications
    $sql_pending = "SELECT id, applicant_name, loan_amount, purpose, status, created_at FROM applications WHERE status = 'pending'";
    $result_pending = $conn->query($sql_pending);
    $pending_applications = [];

    if ($result_pending->num_rows > 0) {
        // Fetch data for pending applications
        while ($row = $result_pending->fetch_assoc()) {
            $pending_applications[] = $row;
        }
    }

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

// Close MySQLi connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Application Status</title>
<link rel="stylesheet" href="styles.css"> <!-- Include your CSS file -->
<style>
body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(to bottom right, #FF5252, #000000); /* Red and black gradient */
    color: #fff;
}

.container {
    width: 80%;
    margin: 50px auto;
    background-color: rgba(0, 0, 0, 0.8);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
}

h1, h2, h3 {
    text-align: center;
}

section {
    margin-top: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #fff;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #FF5252;
    color: white;
}

td {
    background-color: rgba(255, 255, 255, 0.2);
}

button {
    background-color: #FF5252;
    color: white;
    padding: 10px 20px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    margin-top: 10px;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #B71C1C;
}

.details {
    display: none;
    background-color: rgba(255, 255, 255, 0.2);
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    color: #fff;
}
</style>
</head>
<body>
<div class="container">
    <h1>Application Status</h1>

    <!-- Pending Applications -->
    <section>
        <h2>Pending Applications</h2>
        <?php if (!empty($pending_applications)): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Applicant Name</th>
                        <th>Loan Amount</th>
                        <th>Purpose</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pending_applications as $app): ?>
                        <tr>
                            <td><?php echo $app['id']; ?></td>
                            <td><?php echo $app['applicant_name']; ?></td>
                            <td><?php echo $app['loan_amount']; ?></td>
                            <td><?php echo $app['purpose']; ?></td>
                            <td><?php echo $app['status']; ?></td>
                            <td><?php echo $app['created_at']; ?></td>
                            <td>
                                <form method="post" action="">
                                    <input type="hidden" name="verify_application" value="<?php echo $app['id']; ?>">
                                    <button type="submit">Verify</button>
                                </form>
                            </td>
                        </tr>
                        <tr class="details" id="details_<?php echo $app['id']; ?>">
                            <td colspan="7">
                                <strong>Additional Details:</strong><br>
                                ID: <?php echo $app['id']; ?><br>
                                Applicant Name: <?php echo $app['applicant_name']; ?><br>
                                Loan Amount: <?php echo $app['loan_amount']; ?><br>
                                Purpose: <?php echo $app['purpose']; ?><br>
                                Status: <?php echo $app['status']; ?><br>
                                Date: <?php echo $app['created_at']; ?><br>
                                <!-- Add more details as needed -->
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No pending applications found.</p>
        <?php endif; ?>

        <?php if (isset($message)): ?>
            <p><?php echo $message; ?></p>
        <?php endif; ?>
    </section>
</div>
<script>
function toggleDetails(id) {
    var details = document.getElementById(id);
    if (details.style.display === "none") {
        details.style.display = "table-row";
    } else {
        details.style.display = "none";
    }
}
</script>
</body>
</html>
