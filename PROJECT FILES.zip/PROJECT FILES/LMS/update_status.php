<?php 
// Include your database connection file
include 'file/connection.php';
session_start();

// Function to log actions
function logAction($emp_name, $applicant_id, $action, $conn) {
    $timestamp = date('Y-m-d H:i:s');
    $log_stmt = $conn->prepare("INSERT INTO logs (emp_name, applicant_id, type_of_action, date_time) VALUES (?, ?, ?, ?)");
    $log_stmt->bind_param("ssss", $emp_name, $applicant_id, $action, $timestamp);
    $log_stmt->execute();
    $log_stmt->close();
}

// Function to handle application approval or rejection
if (isset($_POST['action']) && isset($_POST['application_id'])) {
    $action = $_POST['action'];
    $application_id = $_POST['application_id'];
    $emp_name = $_SESSION['name']; // Assuming emp_name is stored in session

    // Update status in applications table
    if ($action === 'approve') {
        $sql_update = "UPDATE applications SET status = 'approved' WHERE id = $application_id";
    } elseif ($action === 'reject') {
        $sql_update = "UPDATE applications SET status = 'rejected' WHERE id = $application_id";
    }

    if ($conn->query($sql_update) === TRUE) {
        $message = "Application status updated successfully.";
        logAction($emp_name, $application_id, $action . "_application", $conn);
    } else {
        $message = "Error updating application status: " . $conn->error;
    }
}

try {
    // Query for verified applications with status pending
    $sql_verified = "SELECT va.id AS verified_id, va.applicant_ID, va.verified_at, a.id, a.applicant_name, a.loan_amount, a.purpose, a.status, a.created_at
                     FROM verified_applications va
                     INNER JOIN applications a ON va.applicant_ID = a.id
                     WHERE a.status = 'pending'";
    $result_verified = $conn->query($sql_verified);
    $verified_applications = [];

    if ($result_verified->num_rows > 0) {
        // Fetch data for verified applications
        while ($row = $result_verified->fetch_assoc()) {
            $verified_applications[] = $row;
        }
    }

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

// Close MySQLi connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Verified Applications</title>
<link rel="stylesheet" href="styles.css"> <!-- Include your CSS file -->
<style>
/* Additional styles for application details */
body {
    background-image: url('https://img.freepik.com/free-photo/business-people-shaking-hands-together_53876-14816.jpg?size=626&ext=jpg&ga=GA1.1.759179063.1720939402&semt=sph'); /* Replace with your background image URL */
    background-size: cover;
    background-attachment: fixed;
    color: white;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}
h1 {
    text-align: center;
    color: white;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
table th, table td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid white;
}
th {
    background-color: #B71C1C; /* Red background */
    color: white;
}
td {
    background-color: #D32F2F; /* Darker red background */
}
button {
    padding: 5px 10px;
    border-radius: 5px;
    cursor: pointer;
    margin-right: 5px;
}
button.approve {
    background-color: #4CAF50;
    color: white;
    border: none;
}
button.reject {
    background-color: #f44336;
    color: white;
    border: none;
}
.details {
    display: none;
    background-color: rgba(255, 255, 255, 0.9);
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    color: black;
}
</style>
<script>
function showMessage(message) {
    alert(message);
    // Reload the page to update the listing
    window.location.reload();
}
</script>
</head>
<body>
<div class="container">
    <h1>Verified Applications Dashboard</h1>

    <!-- Verified Applications -->
    <section>
        <?php if (!empty($verified_applications)): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Applicant Name</th>
                        <th>Loan Amount</th>
                        <th>Purpose</th>
                        <th>Status</th>
                        <th>Verified At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($verified_applications as $app): ?>
                        <tr id="application_<?php echo $app['id']; ?>">
                            <td><?php echo $app['id']; ?></td>
                            <td><?php echo $app['applicant_name']; ?></td>
                            <td><?php echo $app['loan_amount']; ?></td>
                            <td><?php echo $app['purpose']; ?></td>
                            <td><?php echo $app['status']; ?></td>
                            <td><?php echo $app['verified_at']; ?></td>
                            <td>
                                <form method="post" action="">
                                    <input type="hidden" name="application_id" value="<?php echo $app['applicant_ID']; ?>">
                                    <button type="submit" name="action" value="approve" class="approve">Approve</button>
                                    <button type="submit" name="action" value="reject" class="reject">Reject</button>
                                </form>
                            </td>
                        </tr>
                        <tr class="details" id="details_<?php echo $app['id']; ?>">
                            <td colspan="7">
                                <strong>Additional Details:</strong><br>
                                ID: <?php echo $app['id']; ?><br>
                                Applicant Name: <?php echo $app['applicant_name']; ?><br>
                                Loan Amount: <?php echo $app['loan_amount']; ?><br>
                                Purpose: <?php echo $app['purpose']; ?><br>
                                Status: <?php echo $app['status']; ?><br>
                                Date: <?php echo $app['created_at']; ?><br>
                                <!-- Add more details as needed -->
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No pending verified applications found.</p>
        <?php endif; ?>

        <?php if (isset($message)): ?>
            <script>
                showMessage("<?php echo $message; ?>");
            </script>
        <?php endif; ?>
    </section>
</div>
</body>
</html>
