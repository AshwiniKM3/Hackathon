<?php
require 'file/connection.php';
session_start();

// Function to log actions
function logAction($emp_name, $applicant_id, $action, $conn) {
    $timestamp = date('Y-m-d H:i:s');
    $log_stmt = $conn->prepare("INSERT INTO logs (emp_name, applicant_id, type_of_action, date_time) VALUES (?, ?, ?, ?)");
    $log_stmt->bind_param("ssss", $emp_name, $applicant_id, $action, $timestamp);
    $log_stmt->execute();
    $log_stmt->close();
}

// Example data (replace with actual data retrieval logic)
$pendingCount = 20; // Replace with actual count from database
$approvedCount = 50; // Replace with actual count from database
$rejectedCount = 10; // Replace with actual count from database
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard</title>
<link rel="stylesheet" href="css/styles.css">
<style>
body {
    
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background: url('https://www.idfcfirstbank.com/content/dam/idfcfirstbank/images/blog/finance/difference-between-money-finance-funds-717X404.jpg') center/cover no-repeat, linear-gradient(135deg, #e040fb, #ff4081); /* Background image and gradient */
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
}

    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(135deg, #e040fb, #ff4081); /* Purple and pink gradient background */
    height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #fff;
}

.navbar {
    width: 100%;
    background: rgba(0, 0, 0, 0.5);
    padding: 10px 20px;
    position: fixed;
    top: 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    z-index: 1000;
}

.navbar .logo {
    font-size: 24px;
    font-weight: bold;
}

.navbar .nav-links {
    list-style: none;
    padding: 0;
    display: flex;
}

.navbar .nav-links li {
    margin: 0 10px;
}

.navbar .nav-links li a {
    color: #fff;
    text-decoration: none;
    padding: 5px 10px;
    border-radius: 5px;
    transition: background 0.3s ease;
}

.navbar .nav-links li a:hover {
    background: rgba(255, 255, 255, 0.3);
}

.dashboard {
    width: 90%;
    max-width: 1200px;
    margin-top: 80px;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.status-block {
    height: 150px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    transition: transform 0.3s ease, background 0.3s ease;
    text-align: center;
    cursor: pointer;
    overflow: hidden;
    position: relative;
}

.status-block:hover {
    transform: translateY(-10px);
    background: rgba(255, 255, 255, 0.3);
}

.status-block h3 {
    margin: 0;
    font-size: 18px;
    margin-bottom: 10px;
}

.status-block .count {
    font-size: 24px;
    font-weight: bold;
}


.status-block.pending {
    background: linear-gradient(135deg, #e040fb, #ff4081); /* Purple and pink gradient */
}


.status-block.approved {
    background: linear-gradient(135deg, #3F51B5, #00FFFF); /* Blue and cyan gradient */
}


.status-block.rejected {
    background: linear-gradient(135deg, #4CAF50, #FFFF00); /* Green and yellow gradient */
}


.status-block.update {
    background: linear-gradient(135deg, #FFC107, #FF0000); /* Red and yellow gradient */
}


.status-block.view-documents {
    background: linear-gradient(135deg, #4CAF50, #00FFFF); /* Green and cyan gradient */
}


.status-block.send-status {
    background: linear-gradient(135deg, #FF4081, #FFFFFF); /* Pink and white gradient */
}

.popup {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: rgba(255, 255, 255, 0.9);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
    display: none;
}

.popup.active {
    display: block;
}
</style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
    
            <ul class="nav-links">
                <li><a href="profile.php">Profile</a></li>
                <li><a href="logout.php" onclick="logLogout()">Logout</a></li>
                <li><a href="analysis.php">Analysis</a></li>
            </ul>
        </div>
    </nav>

    <div class="dashboard">
        <div class="status-block pending" onclick="openPopup('Pending Applications', <?php echo $pendingCount; ?>)">
            <h3>No of Applications Pending</h3>
            <span class="count"><?php echo $pendingCount; ?></span>
        </div>
        <div class="status-block approved" onclick="openPopup('Approved Applications', <?php echo $approvedCount; ?>)">
            <h3>No of Applications Approved</h3>
            <span class="count"><?php echo $approvedCount; ?></span>
        </div>
        <div class="status-block rejected" onclick="openPopup('Rejected Applications', <?php echo $rejectedCount; ?>)">
            <h3>No of Applications Rejected</h3>
            <span class="count"><?php echo $rejectedCount; ?></span>
        </div>
        <div class="status-block update" onclick="openPopup('Update Application Status')">
            <h3>Update Status</h3>
        </div>
        <div class="status-block view-documents" onclick="openPopup('View Documents')">
            <h3>View Documents</h3>
        </div>
        <div class="status-block send-status" onclick="openPopup('Send Status')">
            <h3>Send Status</h3>
        </div>
    </div>

    <div class="popup" id="popup">
        <h2 id="popup-title"></h2>
        <div id="popup-content"></div>
        <button onclick="closePopup()">Close</button>
    </div>

    <script>
        function logLogout() {
            var form = document.createElement("form");
            form.method = "POST";
            form.action = "";
            var input = document.createElement("input");
            input.type = "hidden";
            input.name = "action";
            input.value = "logout";
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }

        function openPopup(title, count = '') {
            document.getElementById('popup-title').textContent = title;
            document.getElementById('popup-content').textContent = count !== '' ? count : 'Details not available.';
            document.getElementById('popup').classList.add('active');
        }

        function closePopup() {
            document.getElementById('popup').classList.remove('active');
        }
    </script>

    <script src="script.js"></script>
</body>
</html>
