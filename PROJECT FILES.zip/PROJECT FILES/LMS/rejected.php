<?php 
require 'file/connection.php';
session_start();

// Function to log actions
function logAction($emp_name, $applicant_id, $action, $conn) {
    $timestamp = date('Y-m-d H:i:s');
    $log_stmt = $conn->prepare("INSERT INTO logs (emp_name, applicant_id, type_of_action, date_time) VALUES (?, ?, ?, ?)");
    $log_stmt->bind_param("ssss", $emp_name, $applicant_id, $action, $timestamp);
    $log_stmt->execute();
    $log_stmt->close();
}

// Function to handle application verification
if (isset($_POST['verify_application'])) {
    $applicant_id = $_POST['verify_application'];
    $current_time = date('Y-m-d H:i:s');
    $emp_name = $_SESSION['name'];

    // Insert into verified_applications table
    $sql_verify = "INSERT INTO verified_applications (applicant_ID, verified_at) VALUES ('$applicant_id', '$current_time')";
    if ($conn->query($sql_verify) === TRUE) {
        $message = "Application successfully verified.";
        logAction($emp_name, $applicant_id, "verify_application", $conn);
    } else {
        $message = "Error verifying application: " . $conn->error;
    }
}

try {
    // Query for rejected applications
    $sql_rejected = "SELECT id, applicant_name, loan_amount, purpose, status, created_at FROM applications WHERE status = 'rejected'";
    $result_rejected = $conn->query($sql_rejected);
    $rejected_applications = [];

    if ($result_rejected->num_rows > 0) {
        // Fetch data for rejected applications
        while ($row = $result_rejected->fetch_assoc()) {
            $rejected_applications[] = $row;
        }
    }

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

// Close MySQLi connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Application Status</title>
<link rel="stylesheet" href="styles.css"> <!-- Include your CSS file -->
<style>
body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(to bottom right, #FF5722, #FF9800); /* Red and orange gradient */
    color: #333; /* Dark text color */
}

.container {
    width: 80%;
    margin: 50px auto;
    background-color: rgba(255, 255, 255, 0.8); /* Lighter background */
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); /* Subtle shadow */
}

h1, h2, h3 {
    text-align: center;
    color: #FF5722; /* Red header */
}

section {
    margin-top: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table, th, td {
    border: 1px solid #ccc; /* Light border color */
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #FF5722; /* Red header background */
    color: white;
}

td {
    background-color: #FFE0B2; /* Light orange background */
}

button {
    background-color: #FF5722; /* Red button background */
    color: white;
    padding: 10px 20px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    margin-top: 10px;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #F4511E; /* Darker red on hover */
}

.details {
    display: none;
    background-color: #FFE0B2; /* Light orange details background */
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    color: #333; /* Dark text color */
}
</style>
</head>
<body>
<div class="container">
    <h1>Application Status</h1>

    <!-- Rejected Applications -->
    <section>
        <h2>Rejected Applications</h2>
        <?php if (!empty($rejected_applications)): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Applicant Name</th>
                        <th>Loan Amount</th>
                        <th>Purpose</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rejected_applications as $app): ?>
                        <tr>
                            <td><?php echo $app['id']; ?></td>
                            <td><?php echo $app['applicant_name']; ?></td>
                            <td><?php echo $app['loan_amount']; ?></td>
                            <td><?php echo $app['purpose']; ?></td>
                            <td><?php echo $app['status']; ?></td>
                            <td><?php echo $app['created_at']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No rejected applications found.</p>
        <?php endif; ?>

        <?php if (isset($message)): ?>
            <p><?php echo $message; ?></p>
        <?php endif; ?>
    </section>
</div>
</body>
</html>
