<?php
// Include your database connection file
include 'file/connection.php';

// Initialize variables
$message_status = '';
$show_form = false;
$show_rejection_form = false;
$applicant_name = '';
$loan_amount = '';
$loan_type = 'Personal Loan';
$interest_rate = '10%';
$term = '36 months';

// Function to handle form submission
if (isset($_POST['applicant_id']) && isset($_POST['go'])) {
    $applicant_id = $_POST['applicant_id'];

    // Query to fetch application details including status
    $sql_fetch = "SELECT id, applicant_name, loan_amount, status FROM applications WHERE id = $applicant_id";
    $result_fetch = $conn->query($sql_fetch);

    if ($result_fetch->num_rows > 0) {
        $row = $result_fetch->fetch_assoc();
        $applicant_name = $row['applicant_name'];
        $loan_amount = $row['loan_amount'];
        $status = $row['status'];

        // Determine action based on status
        if ($status === 'approved') {
            // Show loan approval notification form
            $show_form = true;
        } elseif ($status === 'rejected') {
            // Show rejection reason form
            $show_rejection_form = true;
        } else {
            $message_status = "Application status is not approved or rejected.";
        }
    } else {
        $message_status = "No application found with ID: $applicant_id";
    }
}

// Function to handle approval notification and storage
if (isset($_POST['applicant_id']) && isset($_POST['send'])) {
    $applicant_id = $_POST['applicant_id'];

    // Prepare email content (replace with your email sending logic)
    $subject = "Loan Approval Notification";
    $message = "Dear $applicant_name,\n\n";
    $message .= "We are pleased to inform you that your loan application has been approved.\n\n";
    $message .= "Loan Approval Details:\n";
    $message .= "Applicant ID: $applicant_id\n";
    $message .= "Applicant Name: $applicant_name\n";
    $message .= "Loan Details:\n";
    $message .= "Loan Amount Approved: $loan_amount\n";
    $message .= "Loan Type: $loan_type\n";
    $message .= "Interest Rate: $interest_rate\n";
    $message .= "Term: $term\n";
    $message .= "Please review the attached documents for further details. Our team will contact you shortly to discuss the next steps.\n\n";
    $message .= "Best regards,\n";
    $message .= "[Your Organization's Name]\n";
    $message .= "[Your Contact Information]";

    // Send email (replace with your email sending logic)
    // mail($recipient_email, $subject, $message);

    // Store in approval_sent table
    $sql_store_approval = "INSERT INTO approval_sent (applicant_ID, sent_at) VALUES ('$applicant_id', CURRENT_TIMESTAMP)";
    if ($conn->query($sql_store_approval) === TRUE) {
        // Log action
        logAction("send_approval_notification", $conn);
        $message_status = "Loan approval notification sent successfully.";
    } else {
        $message_status = "Error storing approval sent status: " . $conn->error;
    }
}

// Function to handle rejection reason submission and storage
if (isset($_POST['reject_reason']) && isset($_POST['applicant_id'])) {
    $applicant_id = $_POST['applicant_id'];
    $reject_reason = $_POST['reject_reason'];

    // Store in rejection_sent table
    $sql_store_rejection = "INSERT INTO rejection_sent (applicant_ID, rejection_reason, sent_at) VALUES ('$applicant_id', '$reject_reason', CURRENT_TIMESTAMP)";
    if ($conn->query($sql_store_rejection) === TRUE) {
        // Log action
        logAction("submit_rejection_reason", $conn);
        $message_status = "Rejection reason submitted successfully.";
    } else {
        $message_status = "Error storing rejection reason: " . $conn->error;
    }
}

// Function to log actions
function logAction($action, $conn) {
    $timestamp = date('Y-m-d H:i:s');
    $log_stmt = $conn->prepare("INSERT INTO logs (type_of_action, date_time) VALUES (?, ?)");
    $log_stmt->bind_param("ss", $action, $timestamp);
    $log_stmt->execute();
    $log_stmt->close();
}

// Close MySQLi connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Loan Approval/Rejection Dashboard</title>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-image: url('https://en.idei.club/uploads/posts/2023-02/thumbs/1677230132_en-idei-club-p-bank-interior-krasivo-28.jpg'); /* Replace with your background image URL */
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-color: black; /* Fallback background color */
}

.container {
    max-width: 800px;
    margin: 20px auto;
    padding: 20px;
    background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent black background */
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(255, 0, 0, 0.5); /* Red box shadow for depth */
    color: white;
}

h1 {
    text-align: center;
    color: red; /* Red color for heading */
}

form {
    background-color: rgba(255, 0, 0, 0.7); /* Semi-transparent red background for forms */
    padding: 20px;
    border-radius: 10px;
    margin-top: 20px;
}

label, input, select {
    display: block;
    margin-bottom: 10px;
    width: 100%;
    box-sizing: border-box;
    color: white; /* White text color */
}

input[type="text"], select {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: rgba(0,0,0,0); /* Semi-transparent white background for inputs */
}

button {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    background-color: red; /* Red background for buttons */
    color: white;
    margin-top: 10px;
}

button.send {
    background-color: green; /* Green background for send button */
}

.message {
    margin-top: 10px;
    padding: 10px;
    background-color: rgba(255, 255, 255, 0.2); /* Semi-transparent white background for messages */
    border-radius: 5px;
    color: white; /* White text color */
}
</style>
</head>
<body>
<div class="container">
    <h1>Loan Approval/Rejection Dashboard</h1>

    <!-- Form for Loan Approval/Rejection -->
    <section>
        <form method="post" action="">
            <label for="applicant_id">Enter Applicant ID:</label>
            <input type="text" id="applicant_id" name="applicant_id" required>
            <button type="submit" name="go">Go</button>
        </form>

        <?php if ($show_form): ?>
            <form method="post" action="">
                <input type="hidden" name="applicant_id" value="<?php echo $_POST['applicant_id']; ?>">
                <h2>Loan Approval Notification</h2>
                <p>Dear <?php echo $applicant_name; ?>,</p>
                <p>We are pleased to inform you that your loan application has been approved.</p>
                <p><strong>Loan Approval Details:</strong></p>
                <ul>
                    <li>Applicant ID: <?php echo $applicant_id; ?></li>
                    <li>Applicant Name: <?php echo $applicant_name; ?></li>
                    <li>Loan Amount Approved: <?php echo $loan_amount; ?></li>
                    <li>Loan Type: <?php echo $loan_type; ?></li>
                    <li>Interest Rate: <?php echo $interest_rate; ?></li>
                    <li>Term: <?php echo $term; ?></li>
                </ul>
                <!-- Add more details as needed -->
                <button type="submit" name="send" class="send">Send Approval Notification</button>
            </form>
        <?php endif; ?>

        <?php if ($show_rejection_form): ?>
            <form method="post" action="">
                <input type="hidden" name="applicant_id" value="<?php echo $_POST['applicant_id']; ?>">
                <label for="reject_reason">Select reason for rejection:</label>
                <select id="reject_reason" name="reject_reason" required>
                    <option value="Insufficient Income or Employment History">Insufficient Income or Employment History</option>
                    <option value="Poor Credit History">Poor Credit History</option>
                    <option value="High Debt-to-Income Ratio">High Debt-to-Income Ratio</option>
                    <option value="Incomplete or Inaccurate Application">Incomplete or Inaccurate Application</option>
                    <option value="Unstable Financial Situation">Unstable Financial Situation</option>
                </select>
                <button type="submit" class="send">Submit Rejection Reason</button>
            </form>
        <?php endif; ?>

        <div class="message"><?php echo $message_status; ?></div>
    </section>
</div>
</body>
</html>
