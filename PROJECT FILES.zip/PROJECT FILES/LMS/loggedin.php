<?php 
require 'file/connection.php';
session_start();

// Function to log actions
function logAction($emp_name, $applicant_id, $action, $conn) {
    $timestamp = date('Y-m-d H:i:s');
    $log_stmt = $conn->prepare("INSERT INTO logs (emp_name, applicant_id, type_of_action, date_time) VALUES (?, ?, ?, ?)");
    $log_stmt->bind_param("ssss", $emp_name, $applicant_id, $action, $timestamp);
    $log_stmt->execute();
    $log_stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $emp_name = $_SESSION['name'];
    $applicant_id = ''; // Set this to actual applicant_id if available
    logAction($emp_name, $applicant_id, $action, $conn);
    header("Location: " . $action . ".php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard</title>
<link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <h1 class="logo">Dashboard</h1>
            <ul class="nav-links">
                <li><a href="profile.php">Profile</a></li>
                <li><a href="logout.php" onclick="logLogout()">Logout</a></li>
                <li><a href="analysis.php">Analysis</a></li>
            </ul>
        </div>
    </nav>

    <div class="dashboard">
        <div class="status-blocks">
            <form action="" method="POST">
                <button type="submit" name="action" value="pending" class="status-block pending">
                    <h3>No of Applications Pending</h3>
                    <span class="count">20</span>
                </button>
                <button type="submit" name="action" value="approved" class="status-block approved">
                    <h3>No of Applications Approved</h3>
                    <span class="count">50</span>
                </button>
                <button type="submit" name="action" value="rejected" class="status-block rejected">
                    <h3>No of Applications Rejected</h3>
                    <span class="count">10</span>
                </button>
                <button type="submit" name="action" value="update_status" class="status-block update">
                    <h3>Update Status</h3>
                </button>
                <button type="submit" name="action" value="view_documents" class="status-block view-documents">
                    <h3>View Documents</h3>
                </button>
                <button type="submit" name="action" value="send_status" class="status-block send-status">
                    <h3>Send Status</h3>
                </button>
            </form>
        </div>
    </div>

    <script>
        function logLogout() {
            var form = document.createElement("form");
            form.method = "POST";
            form.action = "";
            var input = document.createElement("input");
            input.type = "hidden";
            input.name = "action";
            input.value = "logout";
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
    </script>

    <script src="script.js"></script>
</body>
</html>
