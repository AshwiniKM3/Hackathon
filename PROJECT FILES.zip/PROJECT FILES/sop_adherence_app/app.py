from flask import Flask, render_template, request, redirect, session, flash
import mysql.connector
import joblib
import numpy as np
from flask import Flask, render_template, request, redirect, session, flash
import mysql.connector
import joblib
import numpy as np
import matplotlib.pyplot as plt
from io import BytesIO
import base64

# Load the saved model and vectorizer
model = joblib.load('model.joblib')
vectorizer = joblib.load('vectorizer.joblib')

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this to a secure random key

# MySQL database connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",  # Replace with your MySQL password
    database="lms2"
)

# Cursor to execute SQL queries
cursor = db.cursor()

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check credentials in admin table
        cursor.execute("SELECT * FROM admin WHERE username = %s AND password = %s", (username, password))
        admin = cursor.fetchone()

        if admin:
            # Store username in session
            session['username'] = username
            return redirect('/dashboard')
        else:
            flash('Invalid credentials. Please try again.', 'error')

    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'username' in session:
        try:
            # Fetch logs where type_of_action is Login or Logout, grouped by emp_name
            cursor.execute("SELECT id, emp_name, type_of_action, date_time FROM logs WHERE type_of_action IN ('Login', 'Logout') ORDER BY emp_name, date_time")
            logs = cursor.fetchall()
            
            # Prepare data for rendering in template
            grouped_logs = {}
            for log in logs:
                emp_name = log[1]  # emp_name is at index 1
                action = log[2]
                timestamp = log[3].strftime('%Y-%m-%d %H:%M:%S')  # Format datetime nicely

                if emp_name not in grouped_logs:
                    grouped_logs[emp_name] = []

                grouped_logs[emp_name].append({'id': log[0], 'action': action, 'timestamp': timestamp})

            return render_template('dashboard.html', grouped_logs=grouped_logs)
        
        except mysql.connector.Error as error:
            flash(f"Error fetching logs: {error}", 'error')
            return redirect('/')
    
    else:
        return redirect('/')

from flask import jsonify, request

@app.route('/analyze', methods=['POST'])
def analyze():
    if request.method == 'POST':
        id = int(request.form['id'])  # Retrieve id of the log entry
        emp_name = request.form['emp_name']
        action = request.form['action']
        timestamp = request.form['timestamp']

        try:
            # Fetch all rows from logs where id > selected id and type_of_action is not Logout
            cursor.execute("SELECT id, emp_name, type_of_action, date_time, applicant_id FROM logs WHERE id > %s AND type_of_action != 'Logout' AND emp_name = %s ORDER BY id", (id, emp_name,))
            analysis_logs = cursor.fetchall()

            # Initialize variables for storing sequence and applicant_id
            current_applicant_id = None
            sequence = []
            scores = []

            for log in analysis_logs:
                log_id = log[0]
                log_emp_name = log[1]
                log_action = log[2]
                log_timestamp = log[3]
                log_applicant_id = log[4]

                if current_applicant_id is None:
                    current_applicant_id = log_applicant_id

                # Check if applicant_id changes
                if log_applicant_id != current_applicant_id:
                    # Predict score for the current sequence
                    if sequence:
                        sequence_str = ' '.join(sequence)
                        sequence_vec = vectorizer.transform([sequence_str])
                        predicted_score = model.predict(sequence_vec)[0]

                        # Store predicted score in the analysis table
                        cursor.execute("INSERT INTO analysis (emp_name, time_stamp, score, applicant_id) VALUES (%s, %s, %s, %s)",
                                       (emp_name, timestamp, predicted_score, current_applicant_id))
                        db.commit()

                        # Clear sequence and scores for the next applicant_id
                        sequence = []
                        scores = []

                    # Update current_applicant_id
                    current_applicant_id = log_applicant_id

                # Append action to sequence
                sequence.append(log_action)

            # Predict score for the last sequence in the loop
            if sequence:
                sequence_str = ' '.join(sequence)
                sequence_vec = vectorizer.transform([sequence_str])
                predicted_score = model.predict(sequence_vec)[0]

                # Store predicted score in the analysis table
                cursor.execute("INSERT INTO analysis (emp_name, time_stamp, score, applicant_id) VALUES (%s, %s, %s, %s)",
                               (emp_name, timestamp, predicted_score, current_applicant_id))
                db.commit()

            # Return a JSON response indicating success
            return jsonify({'status': 'success'})

        except mysql.connector.Error as error:
            # Return an error JSON response
            return jsonify({'status': 'error', 'message': f"Error fetching analysis logs: {error}"}), 500

    # Return an error JSON response if method is not POST
    return jsonify({'status': 'error', 'message': 'Invalid request method'}), 405

@app.route('/view_analysis')
def view_analysis():
    try:
        # Fetch data from analysis table
        cursor.execute("SELECT id, emp_name, time_stamp, score, applicant_id FROM analysis")
        analysis_data = cursor.fetchall()

        # Calculate average adherence percentage
        if analysis_data:
            total_scores = sum([entry[3] for entry in analysis_data])  # Sum of scores
            average_score = total_scores / len(analysis_data)
        else:
            average_score = 0  # Handle case where there are no entries

        return render_template('view_analysis.html', analysis_data=analysis_data, average_score=average_score)

    except mysql.connector.Error as error:
        return f"Error fetching analysis data: {error}"



@app.route('/view_current_sop')
def view_current_sop():
    try:
        # Example steps for Loan Management SOP (replace with actual data retrieval logic)
        steps = [
            "Step 1: Login to the Loan Management System.",
            "Step 2: Review pending applications.",
            "Step 3: Verify applicant documents.",
            "Step 4: Update application status.",
            "Step 5: Logout from the system."
        ]

        return render_template('current_sop.html', steps=steps)

    except Exception as e:
        return f"Error: {str(e)}"


@app.route('/logout')
def logout():
    # Remove username from session
    session.pop('username', None)
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
